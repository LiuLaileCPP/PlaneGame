//#pragma once
//#include<list>
//#include"Flame.h"
//using namespace std;
//
//class FlameList
//{
//public:
//	list<Flame*> m_listFlame;
//public:
//	FlameList();
//	~FlameList();
//public:
//	virtual void ShowAllFlame();
//	virtual void MoveAllFlame();
//};