//#pragma once
//#include<easyx.h>
//#include<random>
//#include"../Player/CPlayer.h"
//using namespace std;
//class Flame
//{
//public:
//	int m_x1;
//	int m_y1;
//	int m_showId;
//	IMAGE m_imgFlame;
//	static random_device rd;
//public:
//	Flame();
//	virtual ~Flame();
//public:
//	virtual void InitFlame();
//	virtual void ShowFlame() ;
//	virtual void MoveFlame(int step) ;
//	virtual bool IssHitFoe(CPlayer& player);
//};