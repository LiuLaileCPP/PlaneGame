//#pragma once
//#include"CFoe.h"
//class CFoeFlame :public CFoe
//{
//public:
//	virtual void InitFoe() override;
//	virtual void InitFoe1() override;
//	virtual void ShowFoe() override;
//	bool IssHitFoe(CPlayer& player) override;
//	bool IssHitGun(CGunner* Gun) override;
//};
